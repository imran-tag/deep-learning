package fr.uha.hassenforder.nn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NnApplication {

	public static void main(String[] args) {
		SpringApplication.run(NnApplication.class, args);
	}

}
